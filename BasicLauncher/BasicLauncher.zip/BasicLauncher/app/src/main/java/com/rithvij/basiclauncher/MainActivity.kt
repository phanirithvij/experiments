package com.rithvij.basiclauncher

import android.app.WallpaperManager
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    private val tag = "MainActivity"
    private lateinit var wallpaperManager: WallpaperManager
    private lateinit var mygestureDetector: GestureDetector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        wallpaperManager = WallpaperManager.getInstance(applicationContext)
        mygestureDetector = GestureDetector(this@MainActivity, MyGestureDetector())


        Log.d(tag, wallpaperManager.wallpaperInfo.settingsActivity)
        Log.d(tag, wallpaperManager.wallpaperInfo.packageName)

        val touchListener = View.OnTouchListener { _, event ->
            mygestureDetector.onTouchEvent(event)
        }
        clayout.setOnTouchListener(touchListener)

        button2.setOnClickListener {
            // To open current live wallpaper's activity
            // https://stackoverflow.com/a/59156060/8608146
            val intent = Intent()
                .setClassName(
                    wallpaperManager.wallpaperInfo.packageName,
                    wallpaperManager.wallpaperInfo.settingsActivity
                )
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
    }

    inner class MyGestureDetector : GestureDetector.SimpleOnGestureListener() {
//        init {
//            Log.d(tag, "Init Gesture Detector")
//        }
        override fun onDoubleTapEvent(e: MotionEvent?): Boolean {
//            Log.d(tag, "double tap ${e!!.actionMasked} ${e.action}")
            onBtnDoubleTap(e)
            return super.onDoubleTap(e)
        }

        override fun onSingleTapUp(e: MotionEvent?): Boolean {
//            Log.d(tag,"single tap ${e!!.actionMasked} ${e.action}")
            onBtnDoubleTap(e)
            return super.onSingleTapConfirmed(e)
        }

    }

    //    https://github.com/LawnchairLauncher/Lawnchair/blob/903a6398e81c1dda2991cc2292ae076e185c57b7/src/com/android/launcher3/Workspace.java#L1541
    fun onBtnDoubleTap(event: MotionEvent?) {
//        Log.d(tag, "Double tap func")
        val position: Array<Int> = arrayOf(0, 0)
        clayout.getLocationOnScreen(position.toIntArray())
        // safe check
        event!!
        position[0] += event.x.toInt()
        position[1] += event.y.toInt()

        wallpaperManager.sendWallpaperCommand(
            clayout.windowToken,
            if (event.action == MotionEvent.ACTION_UP)
                WallpaperManager.COMMAND_TAP else
                WallpaperManager.COMMAND_SECONDARY_TAP,
            position[0], position[1], 0, null
        )
    }
}

